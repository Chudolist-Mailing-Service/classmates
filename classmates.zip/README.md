Classmates - flask app holding a list of classmates:

<http://chudoclass.us-west-2.elasticbeanstalk.com/>
